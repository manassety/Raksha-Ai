from flask import Flask, request, jsonify
import cv2
import numpy as np
import face_recognition
import base64
import os
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)

# Initialize OpenCV HOG people detector for human body detection
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# Initialize YOLOv3-tiny for Object and Human Detection
net = cv2.dnn.readNet(os.path.join(BASE_DIR, "yolov3-tiny.weights"), os.path.join(BASE_DIR, "yolov3-tiny.cfg"))
with open(os.path.join(BASE_DIR, "coco.names"), "r") as f:
    classes = [line.strip() for line in f.readlines()]
layer_names = net.getLayerNames()
# Handle output layers format depending on OpenCV version
try:
    output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers()]
except:
    output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]

# In-memory storage for encodings and evidence count
user_encodings = {}
evidence_count = {}

# Directory to save evidence images
evidence_dir = os.path.join(BASE_DIR, "evidence")
os.makedirs(evidence_dir, exist_ok=True)

@app.route('/api/auth/register', methods=['POST'])
def register_face():
    data = request.json
    user_id = data.get('user_id')
    image_base64 = data.get('image')
    
    if not user_id or not image_base64:
        return jsonify({"error": "Missing user_id or image"}), 400
        
    try:
        if ',' in image_base64:
            image_base64 = image_base64.split(',')[1]
        img_data = base64.b64decode(image_base64)
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        face_encodings = face_recognition.face_encodings(rgb_img)
        if len(face_encodings) > 0:
            user_encodings[user_id] = face_encodings[0].tolist()
            return jsonify({
                "success": True, 
                "message": "Face registered successfully",
                "encoding": face_encodings[0].tolist()
            })
        else:
            return jsonify({"success": False, "error": "No face found in image"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/evidence/analyze', methods=['POST'])
def analyze_frame():
    data = request.json
    user_id = data.get('user_id')
    image_base64 = data.get('image')
    
    if not user_id or not image_base64:
        return jsonify({"error": "Missing user_id or image"}), 400
        
    try:
        if ',' in image_base64:
            image_base64 = image_base64.split(',')[1]
        img_data = base64.b64decode(image_base64)
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        height, width, channels = img.shape
        
        # YOLO Object Detection
        blob = cv2.dnn.blobFromImage(img, 0.00392, (320, 320), (0, 0, 0), True, crop=False)
        net.setInput(blob)
        outs = net.forward(output_layers)
        
        class_ids = []
        confidences = []
        yolo_boxes = []
        
        for out in outs:
            for detection in out:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                if confidence > 0.3:
                    center_x = int(detection[0] * width)
                    center_y = int(detection[1] * height)
                    w = int(detection[2] * width)
                    h = int(detection[3] * height)
                    x = int(center_x - w / 2)
                    y = int(center_y - h / 2)
                    yolo_boxes.append([x, y, w, h])
                    confidences.append(float(confidence))
                    class_ids.append(class_id)
                    
        indexes = cv2.dnn.NMSBoxes(yolo_boxes, confidences, 0.3, 0.4)
        
        human_detected = False
        boxes = []
        
        for i in range(len(yolo_boxes)):
            if i in indexes:
                x, y, w, h = yolo_boxes[i]
                label = str(classes[class_ids[i]])
                
                if label == "person":
                    human_detected = True
                    label_text = "Human Identified"
                    color = (0, 0, 255) # Red
                else:
                    label_text = label.capitalize()
                    color = (255, 165, 0) # Orange
                
                cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
                cv2.putText(img, label_text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                boxes.append({"label": label_text})

        evidence_saved = False
        # Save only if human is detected
        if human_detected:
            count = evidence_count.get(user_id, 0)
            if count < 10:
                timestamp = int(time.time())
                cv2.imwrite(os.path.join(evidence_dir, f"human_{user_id}_{timestamp}.jpg"), img)
                evidence_count[user_id] = count + 1
                evidence_saved = True
                
        # Encode the annotated image to base64 to send back to the stream
        _, buffer = cv2.imencode('.jpg', img)
        annotated_base64 = base64.b64encode(buffer).decode('utf-8')
                
        return jsonify({
            "success": True, 
            "unknown_detected": human_detected,
            "evidence_saved": evidence_saved,
            "total_evidence_saved": evidence_count.get(user_id, 0),
            "annotated_frame": annotated_base64
        })
            
    except Exception as e:
        return jsonify({"error": str(e)}), 500


import subprocess
import threading

def run_adb_automation(phone_number, message):
    try:
        # Check if device is connected
        result = subprocess.run(['adb', 'devices'], capture_output=True, text=True)
        if "device\n" not in result.stdout and "\tdevice" not in result.stdout:
            print("[ADB] Error: No Android device connected via ADB.")
            return False, "No device connected via USB Debugging"

        # Step 1: Switch to SMS App with pre-filled number and message
        print(f"[ADB] Opening SMS app for {phone_number}...")
        # Escape spaces for ADB shell
        escaped_message = message.replace(' ', '\\%20').replace('&', '\\%26')
        cmd_open = f'adb shell am start -a android.intent.action.SENDTO -d sms:{phone_number} --es sms_body "{escaped_message}"'
        subprocess.run(cmd_open, shell=True)
        
        # Wait for app to open
        time.sleep(2)
        
        # Step 2: Tap the send button (Coordinates for typical modern Android)
        print("[ADB] Tapping Send button...")
        subprocess.run('adb shell input tap 950 2150', shell=True)
        # Fallback keyevents
        subprocess.run('adb shell input keyevent 22', shell=True) # Right
        subprocess.run('adb shell input keyevent 66', shell=True) # Enter
        
        time.sleep(1.5)
        
        # Step 3: Switch back to the Safety App!
        print("[ADB] Switching back to Safety App...")
        subprocess.run('adb shell input keyevent 4', shell=True) # Back
        time.sleep(0.5)
        subprocess.run('adb shell input keyevent 4', shell=True) # Back
        # Optional: Bring Expo back to front explicitly
        subprocess.run('adb shell monkey -p host.exp.exponent -c android.intent.category.LAUNCHER 1', shell=True)
        
        print("[ADB] Automation completed successfully!")
        return True, "Success"
    except Exception as e:
        print(f"[ADB] Automation error: {e}")
        return False, str(e)


@app.route('/api/sos/automate', methods=['POST'])
def automate_sos():
    """
    FEATURE 1: SOS Automation System
    Uses ADB to control the mobile device, switch to SMS, send location, and return to app.
    """
    data = request.json or {}
    phone_number = data.get('phone', '9411596016')
    message = data.get('message', 'EMERGENCY SOS! I need help!')
    
    # Run synchronously to check device connection
    success, msg = run_adb_automation(phone_number, message)
    
    return jsonify({
        "success": success,
        "message": msg
    })

@app.route('/api/sos/send_cloud_sms', methods=['POST'])
def send_cloud_sms():
    """
    FEATURE: Cloud Backend SMS (Twilio / Fast2SMS API)
    Silently sends SMS to emergency contacts via the cloud without opening the mobile SMS app.
    """
    data = request.json or {}
    numbers = data.get('numbers', [])
    message = data.get('message', 'EMERGENCY SOS! I need help!')
    
    try:
        # -----------------------------------------------------
        # TODO: Add real Twilio or Fast2SMS Credentials here
        # TWILIO_ACCOUNT_SID = 'your_account_sid'
        # TWILIO_AUTH_TOKEN = 'your_auth_token'
        # TWILIO_PHONE_NUMBER = '+1234567890'
        # client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        # for number in numbers:
        #     client.messages.create(body=message, from_=TWILIO_PHONE_NUMBER, to=number)
        # -----------------------------------------------------
        
        # Simulating cloud SMS processing for demo
        import time
        time.sleep(1)
        
        print(f"\n[CLOUD SMS] EMERGENCY ALERTS SENT SUCCESSFULLY via GATEWAY!")
        print(f"[CLOUD SMS] Recipients: {', '.join(numbers)}")
        print(f"[CLOUD SMS] Message: {message}\n")
        
        return jsonify({
            "success": True,
            "message": f"Cloud SMS gateway sent alerts to {len(numbers)} contacts silently in the background."
        })
    except Exception as e:
        print(f"[CLOUD SMS] Error: {e}")
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == '__main__':
    # Start server
    print("RakshaAI Python AI Server running on port 5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
